"""Satellite swath topology.

not usable yet
"""

from pyresample.geometry import SwathDefinition

from .data import Data


class SatelliteSwath(Data):
    """The Satellite Swath topology class. Not being used and not recommended.

    A class that gives particular representation to Satellite Swath data.
    """

    def _set_geom(self):
        lons, lats = self.get_coordinates(["longitude", "latitude"])
        swath_def = SwathDefinition(lons=lons, lats=lats, crs=self.crs)
        self.geom = swath_def.compute_optimal_bb_area(self.crs.proj4_params)
        return self.geom
